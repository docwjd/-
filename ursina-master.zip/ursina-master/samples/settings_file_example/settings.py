from ursina import *

window.fullscreen = True
window.color=color.black
Text.size *= 2

Button.color = color.azure
color.text_color = color.orange
